from django.apps import AppConfig


class BoilerinfoConfig(AppConfig):
    name = 'boilerinfo'
